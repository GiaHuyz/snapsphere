(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_layout_tsx_36ac26._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_layout_tsx_36ac26._.js",
  "chunks": [
    "static/chunks/_f1927a._.js",
    "static/chunks/node_modules_next_74ca4d._.js",
    "static/chunks/node_modules_@clerk_shared_dist_b6e28d._.js",
    "static/chunks/node_modules_swr_dist_37de6b._.js",
    "static/chunks/node_modules_@clerk_clerk-react_dist_43ba6e._.js",
    "static/chunks/node_modules_zod_lib_index_mjs_ee760a._.js",
    "static/chunks/node_modules_adff16._.js",
    "static/chunks/app_d0d911._.css"
  ],
  "source": "dynamic"
});
