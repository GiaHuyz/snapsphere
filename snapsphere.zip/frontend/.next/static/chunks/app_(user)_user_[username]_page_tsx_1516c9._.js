(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_(user)_user_[username]_page_tsx_1516c9._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_(user)_user_[username]_page_tsx_1516c9._.js",
  "chunks": [
    "static/chunks/_b2307d._.js",
    "static/chunks/node_modules_88a9b2._.js"
  ],
  "source": "dynamic"
});
