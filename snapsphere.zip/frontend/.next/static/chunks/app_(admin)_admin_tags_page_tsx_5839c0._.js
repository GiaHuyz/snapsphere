(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_(admin)_admin_tags_page_tsx_5839c0._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_(admin)_admin_tags_page_tsx_5839c0._.js",
  "chunks": [
    "static/chunks/node_modules_3318f3._.js",
    "static/chunks/_e31cc7._.js"
  ],
  "source": "dynamic"
});
