(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_(admin)_admin_pins_page_tsx_5839c0._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_(admin)_admin_pins_page_tsx_5839c0._.js",
  "chunks": [
    "static/chunks/_089337._.js",
    "static/chunks/node_modules_0e8d68._.js"
  ],
  "source": "dynamic"
});
