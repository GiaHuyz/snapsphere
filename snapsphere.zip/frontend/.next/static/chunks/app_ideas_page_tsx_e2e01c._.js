(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_ideas_page_tsx_e2e01c._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_ideas_page_tsx_e2e01c._.js",
  "chunks": [
    "static/chunks/_e43736._.js"
  ],
  "source": "dynamic"
});
