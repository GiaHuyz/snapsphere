(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_(admin)_admin_layout_tsx_dea3ec._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_(admin)_admin_layout_tsx_dea3ec._.js",
  "chunks": [
    "static/chunks/node_modules_c3528a._.js",
    "static/chunks/_2074a9._.js"
  ],
  "source": "dynamic"
});
