(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_(admin)_admin_reports_page_tsx_5839c0._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_(admin)_admin_reports_page_tsx_5839c0._.js",
  "chunks": [
    "static/chunks/_cac8cc._.js",
    "static/chunks/node_modules_9b7890._.js"
  ],
  "source": "dynamic"
});
