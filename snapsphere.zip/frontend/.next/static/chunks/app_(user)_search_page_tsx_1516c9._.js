(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_(user)_search_page_tsx_1516c9._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_(user)_search_page_tsx_1516c9._.js",
  "chunks": [
    "static/chunks/node_modules_783e9f._.js",
    "static/chunks/_77e482._.js"
  ],
  "source": "dynamic"
});
