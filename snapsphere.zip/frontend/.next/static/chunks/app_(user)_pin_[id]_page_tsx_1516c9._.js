(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_(user)_pin_[id]_page_tsx_1516c9._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_(user)_pin_[id]_page_tsx_1516c9._.js",
  "chunks": [
    "static/chunks/_6d555a._.js",
    "static/chunks/node_modules_0bdb11._.js",
    "static/chunks/node_modules_emoji-picker-react_dist_emoji-picker-react_esm_c267af.js"
  ],
  "source": "dynamic"
});
