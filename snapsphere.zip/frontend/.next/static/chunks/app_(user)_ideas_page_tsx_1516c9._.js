(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_(user)_ideas_page_tsx_1516c9._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_(user)_ideas_page_tsx_1516c9._.js",
  "chunks": [
    "static/chunks/_e5bb52._.js"
  ],
  "source": "dynamic"
});
