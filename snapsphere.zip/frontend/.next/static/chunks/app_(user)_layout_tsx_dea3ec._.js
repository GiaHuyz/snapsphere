(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_(user)_layout_tsx_dea3ec._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_(user)_layout_tsx_dea3ec._.js",
  "chunks": [
    "static/chunks/_9184df._.js",
    "static/chunks/node_modules_7ece96._.js",
    "static/chunks/node_modules_next_b46f50._.js",
    "static/chunks/node_modules_zod_lib_index_mjs_ee760a._.js",
    "static/chunks/node_modules_@cloudinary_transformation-builder-sdk_684d83._.js",
    "static/chunks/node_modules_@radix-ui_c662ca._.js",
    "static/chunks/node_modules_cmdk_e1fc7b._.js",
    "static/chunks/node_modules_@floating-ui_9ec1fa._.js",
    "static/chunks/node_modules_563bb1._.js"
  ],
  "source": "dynamic"
});
