module.exports = {

"[project]/lib/constants.ts [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "PAGE_SIZE_BOARDS": (()=>PAGE_SIZE_BOARDS),
    "PAGE_SIZE_COMMENTS": (()=>PAGE_SIZE_COMMENTS),
    "PAGE_SIZE_PINS": (()=>PAGE_SIZE_PINS),
    "PAGE_SIZE_TAGS": (()=>PAGE_SIZE_TAGS),
    "PAGE_SIZE_USERS_LIKES": (()=>PAGE_SIZE_USERS_LIKES),
    "ReportReason": (()=>ReportReason),
    "ReportType": (()=>ReportType)
});
const PAGE_SIZE_COMMENTS = 20;
const PAGE_SIZE_PINS = 20;
const PAGE_SIZE_BOARDS = 20;
const PAGE_SIZE_USERS_LIKES = 20;
const PAGE_SIZE_TAGS = 20;
var ReportReason = /*#__PURE__*/ function(ReportReason) {
    ReportReason["SPAM"] = "spam";
    ReportReason["NUDITY"] = "nudity";
    ReportReason["SELF_HARM"] = "self-harm";
    ReportReason["MISINFORMATION"] = "misinformation";
    ReportReason["HATE"] = "hate";
    ReportReason["DANGEROUS"] = "dangerous";
    ReportReason["HARASSMENT"] = "harassment";
    ReportReason["VIOLENCE"] = "violence";
    ReportReason["PRIVACY"] = "privacy";
    ReportReason["INTELLECTUAL_PROPERTY"] = "intellectual-property";
    return ReportReason;
}({});
var ReportType = /*#__PURE__*/ function(ReportType) {
    ReportType["PIN"] = "pin";
    ReportType["COMMENT"] = "comment";
    ReportType["USER"] = "user";
    return ReportType;
}({});
}}),
"[project]/lib/create-server-action.ts [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
/* eslint-disable @typescript-eslint/no-explicit-any */ __turbopack_esm__({
    "default": (()=>createServerAction)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$clerk$2f$nextjs$2f$dist$2f$esm$2f$app$2d$router$2f$server$2f$auth$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@clerk/nextjs/dist/esm/app-router/server/auth.js [app-rsc] (ecmascript)");
;
function createServerAction(handler, options = {
    requireAuth: true,
    isAdmin: false
}) {
    return async (data, ...args)=>{
        if (options.requireAuth) {
            const { userId } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$clerk$2f$nextjs$2f$dist$2f$esm$2f$app$2d$router$2f$server$2f$auth$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["auth"])();
            if (!userId) {
                throw new Error('Unauthorized');
            }
        }
        if (options.isAdmin) {
            const { sessionClaims } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$clerk$2f$nextjs$2f$dist$2f$esm$2f$app$2d$router$2f$server$2f$auth$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["auth"])();
            if (sessionClaims?.metadata.role !== 'admin') {
                throw new Error('Unauthorized');
            }
        }
        return handler(data, ...args);
    };
}
}}),
"[project]/lib/errors.ts [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "getErrorMessage": (()=>getErrorMessage),
    "isActionError": (()=>isActionError)
});
function isActionError(error) {
    return typeof error === 'object' && error != null && 'error' in error && typeof error.error === 'string';
}
const getErrorMessage = (error)=>{
    if (error instanceof Error) {
        return error.message;
    }
    return 'Something went wrong';
};
}}),
"[project]/lib/http-request.ts [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
/* eslint-disable @typescript-eslint/no-explicit-any */ __turbopack_esm__({
    "HttpRequest": (()=>HttpRequest)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$headers$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/headers.js [app-rsc] (ecmascript)");
;
class HttpRequest {
    static async getHeaders(isFormData = false) {
        const cookieStore = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$headers$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["cookies"])();
        return {
            ...isFormData ? {} : {
                'Content-Type': 'application/json'
            },
            Cookie: cookieStore.toString()
        };
    }
    static buildUrl(endpoint) {
        let baseUrl = process.env.API_URL;
        if (baseUrl.endsWith('/')) {
            baseUrl = baseUrl.slice(0, -1);
        }
        if (endpoint.startsWith('/')) {
            endpoint = endpoint.slice(1);
        }
        return `${baseUrl}/${endpoint}`;
    }
    static async request(endpoint, method, body, options) {
        const isFormData = body instanceof FormData;
        const headers = await this.getHeaders(isFormData);
        if (!body) {
            delete headers['Content-Type'];
        }
        const response = await fetch(this.buildUrl(endpoint), {
            method,
            headers,
            body: isFormData ? body : body ? JSON.stringify(body) : undefined,
            ...options
        });
        return this.handleResponse(response);
    }
    static async handleResponse(response) {
        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.message) || 'Something went wrong';
        }
        if (!response.headers.get('Content-Type') || response.headers.get('Content-Length') === '0') {
            return null;
        }
        const data = await response.json();
        return data;
    }
    static async get(endpoint, options) {
        return this.request(endpoint, 'GET', undefined, options);
    }
    static async post(endpoint, body, options) {
        return this.request(endpoint, 'POST', body, options);
    }
    static async put(endpoint, body, options) {
        return this.request(endpoint, 'PUT', body, options);
    }
    static async patch(endpoint, body, options) {
        return this.request(endpoint, 'PATCH', body, options);
    }
    static async delete(endpoint, options) {
        return this.request(endpoint, 'DELETE', undefined, options);
    }
}
}}),
"[project]/actions/pin-actions.ts [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
/* __next_internal_action_entry_do_not_use__ {"7f0a8ba792fe2979b001162ebaeb3552c0dc5138bd":"getRecommendedPinsAction","7f15cf7ac9755fd6547f388aba7835dc68010afcb2":"getPinsByBoardIdAction","7f596c1854292cab27a462e1dc59d3a10e2c5d0abe":"getAllPinsUserAction","7f5ffe0105db9c1a918323b8b149d6c0113aea8a93":"getPinDetailAction","7f6cc309a04f3fd27e69771f80a293833e7abea83f":"createPin","7f7bfaa784e451efe4f77a2e145b3797a730e5f40f":"fetchImageFromUrl","7fa354ce341ae209e13a86c1bf51e584b5bec0fd4c":"editPinAction","7fa619718bd611ece80da6463cb554689f8cf53e69":"deletePinFromBoardAction","7fe2d0b8d6e93ff0461edc4cd911372db17af3342d":"savePinToBoardAction","7fef2da2274bd20f2c25ba1a1f7e72584a0dd4db4d":"deletePinAction"} */ __turbopack_esm__({
    "createPin": (()=>createPin),
    "deletePinAction": (()=>deletePinAction),
    "deletePinFromBoardAction": (()=>deletePinFromBoardAction),
    "editPinAction": (()=>editPinAction),
    "fetchImageFromUrl": (()=>fetchImageFromUrl),
    "getAllPinsUserAction": (()=>getAllPinsUserAction),
    "getPinDetailAction": (()=>getPinDetailAction),
    "getPinsByBoardIdAction": (()=>getPinsByBoardIdAction),
    "getRecommendedPinsAction": (()=>getRecommendedPinsAction),
    "savePinToBoardAction": (()=>savePinToBoardAction)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/server-reference.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$app$2d$render$2f$encryption$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/app-render/encryption.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$constants$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/lib/constants.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$create$2d$server$2d$action$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/lib/create-server-action.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$errors$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/lib/errors.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$http$2d$request$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/lib/http-request.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$validate$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-validate.js [app-rsc] (ecmascript)");
;
;
;
;
;
;
const /*#__TURBOPACK_DISABLE_EXPORT_MERGING__*/ savePinToBoardAction = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$create$2d$server$2d$action$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"])(async (data)=>{
    try {
        const res = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$http$2d$request$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["HttpRequest"].post('/board-pin', data);
        return res;
    } catch (error) {
        return {
            error: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$errors$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getErrorMessage"])(error)
        };
    }
});
const /*#__TURBOPACK_DISABLE_EXPORT_MERGING__*/ getAllPinsUserAction = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$create$2d$server$2d$action$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"])(async (queryParams)=>{
    try {
        queryParams.page = queryParams.page || 1;
        queryParams.pageSize = queryParams.pageSize || __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$constants$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["PAGE_SIZE_PINS"];
        const queryString = Object.entries(queryParams).filter(([, value])=>value !== undefined).map(([key, value])=>`${key}=${value}`).join('&');
        const res = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$http$2d$request$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["HttpRequest"].get(`/pins?${queryString}`, {
            cache: 'force-cache'
        });
        return res;
    } catch (error) {
        return {
            error: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$errors$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getErrorMessage"])(error)
        };
    }
}, {
    requireAuth: false
});
const /*#__TURBOPACK_DISABLE_EXPORT_MERGING__*/ createPin = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$create$2d$server$2d$action$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"])(async (data)=>{
    try {
        const res = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$http$2d$request$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["HttpRequest"].post('/pins', data);
        return res;
    } catch (error) {
        return {
            error: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$errors$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getErrorMessage"])(error)
        };
    }
});
const /*#__TURBOPACK_DISABLE_EXPORT_MERGING__*/ fetchImageFromUrl = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$create$2d$server$2d$action$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"])(async (url)=>{
    try {
        const response = await fetch(url);
        if (!response.ok) {
            throw new Error(`Failed to fetch image: ${response.statusText}`);
        }
        const contentType = response.headers.get('content-type');
        if (!contentType || !contentType.startsWith('image/')) {
            throw new Error('The URL does not point to a valid image');
        }
        const arrayBuffer = await response.arrayBuffer();
        const base64 = Buffer.from(arrayBuffer).toString('base64');
        return `data:${contentType};base64,${base64}`;
    } catch (error) {
        return {
            error: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$errors$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getErrorMessage"])(error)
        };
    }
});
const /*#__TURBOPACK_DISABLE_EXPORT_MERGING__*/ deletePinAction = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$create$2d$server$2d$action$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"])(async (id)=>{
    try {
        await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$http$2d$request$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["HttpRequest"].delete(`/pins/${id}`);
    } catch (error) {
        return {
            error: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$errors$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getErrorMessage"])(error)
        };
    }
});
const /*#__TURBOPACK_DISABLE_EXPORT_MERGING__*/ deletePinFromBoardAction = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$create$2d$server$2d$action$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"])(async (id)=>{
    try {
        await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$http$2d$request$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["HttpRequest"].delete(`/board-pin/${id}`);
    } catch (error) {
        return {
            error: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$errors$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getErrorMessage"])(error)
        };
    }
});
const /*#__TURBOPACK_DISABLE_EXPORT_MERGING__*/ editPinAction = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$create$2d$server$2d$action$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"])(async (data)=>{
    try {
        const { _id, ...updateData } = data;
        const res = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$http$2d$request$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["HttpRequest"].patch(`/pins/${_id}`, updateData);
        return res;
    } catch (error) {
        return {
            error: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$errors$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getErrorMessage"])(error)
        };
    }
});
const /*#__TURBOPACK_DISABLE_EXPORT_MERGING__*/ getPinDetailAction = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$create$2d$server$2d$action$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"])(async (id)=>{
    try {
        const res = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$http$2d$request$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["HttpRequest"].get(`/pins/${id}`, {
            cache: 'force-cache'
        });
        return res;
    } catch (error) {
        return {
            error: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$errors$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getErrorMessage"])(error)
        };
    }
});
const /*#__TURBOPACK_DISABLE_EXPORT_MERGING__*/ getPinsByBoardIdAction = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$create$2d$server$2d$action$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"])(async (data)=>{
    try {
        data.page = data.page || 1;
        data.pageSize = data.pageSize || __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$constants$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["PAGE_SIZE_PINS"];
        const queryString = Object.entries(data).filter(([, value])=>value !== undefined).map(([key, value])=>`${key}=${value}`).join('&');
        const res = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$http$2d$request$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["HttpRequest"].get(`/board-pin?${queryString}`, {
            cache: 'force-cache'
        });
        return res.filter(({ pin })=>pin).map(({ _id, pin })=>{
            return {
                ...pin,
                board_pin_id: _id
            };
        });
    } catch (error) {
        return {
            error: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$errors$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getErrorMessage"])(error)
        };
    }
});
const /*#__TURBOPACK_DISABLE_EXPORT_MERGING__*/ getRecommendedPinsAction = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$create$2d$server$2d$action$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"])(async (queryParams)=>{
    try {
        queryParams.page = queryParams.page || 1;
        queryParams.pageSize = queryParams.pageSize || __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$constants$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["PAGE_SIZE_PINS"];
        const queryString = Object.entries(queryParams).filter(([, value])=>value !== undefined).map(([key, value])=>`${key}=${value}`).join('&');
        const res = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$http$2d$request$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["HttpRequest"].get(`/pins/recommended?${queryString}`, {
            cache: 'force-cache'
        });
        return res;
    } catch (error) {
        return {
            error: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$errors$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getErrorMessage"])(error)
        };
    }
});
;
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$validate$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["ensureServerEntryExports"])([
    savePinToBoardAction,
    getAllPinsUserAction,
    createPin,
    fetchImageFromUrl,
    deletePinAction,
    deletePinFromBoardAction,
    editPinAction,
    getPinDetailAction,
    getPinsByBoardIdAction,
    getRecommendedPinsAction
]);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(savePinToBoardAction, "7fe2d0b8d6e93ff0461edc4cd911372db17af3342d", null);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(getAllPinsUserAction, "7f596c1854292cab27a462e1dc59d3a10e2c5d0abe", null);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(createPin, "7f6cc309a04f3fd27e69771f80a293833e7abea83f", null);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(fetchImageFromUrl, "7f7bfaa784e451efe4f77a2e145b3797a730e5f40f", null);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(deletePinAction, "7fef2da2274bd20f2c25ba1a1f7e72584a0dd4db4d", null);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(deletePinFromBoardAction, "7fa619718bd611ece80da6463cb554689f8cf53e69", null);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(editPinAction, "7fa354ce341ae209e13a86c1bf51e584b5bec0fd4c", null);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(getPinDetailAction, "7f5ffe0105db9c1a918323b8b149d6c0113aea8a93", null);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(getPinsByBoardIdAction, "7f15cf7ac9755fd6547f388aba7835dc68010afcb2", null);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(getRecommendedPinsAction, "7f0a8ba792fe2979b001162ebaeb3552c0dc5138bd", null);
}}),
"[project]/components/pages/admin/pin-table.tsx (client proxy) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "PinsTable": (()=>PinsTable)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server-edge.js [app-rsc] (ecmascript)");
;
const PinsTable = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call PinsTable() from the server but PinsTable is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/components/pages/admin/pin-table.tsx <module evaluation>", "PinsTable");
}}),
"[project]/components/pages/admin/pin-table.tsx (client proxy)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "PinsTable": (()=>PinsTable)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server-edge.js [app-rsc] (ecmascript)");
;
const PinsTable = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call PinsTable() from the server but PinsTable is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/components/pages/admin/pin-table.tsx", "PinsTable");
}}),
"[project]/components/pages/admin/pin-table.tsx [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$pages$2f$admin$2f$pin$2d$table$2e$tsx__$28$client__proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_import__("[project]/components/pages/admin/pin-table.tsx (client proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$pages$2f$admin$2f$pin$2d$table$2e$tsx__$28$client__proxy$29$__ = __turbopack_import__("[project]/components/pages/admin/pin-table.tsx (client proxy)");
;
__turbopack_export_namespace__(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$pages$2f$admin$2f$pin$2d$table$2e$tsx__$28$client__proxy$29$__);
}}),
"[project]/lib/utils.ts [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "checkBoardDetailsPage": (()=>checkBoardDetailsPage),
    "checkPinDetailsPage": (()=>checkPinDetailsPage),
    "checkUserPage": (()=>checkUserPage),
    "cn": (()=>cn),
    "getPublicId": (()=>getPublicId)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/clsx/dist/clsx.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$tailwind$2d$merge$2f$dist$2f$bundle$2d$mjs$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/tailwind-merge/dist/bundle-mjs.mjs [app-rsc] (ecmascript)");
;
;
function cn(...inputs) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$tailwind$2d$merge$2f$dist$2f$bundle$2d$mjs$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["twMerge"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["clsx"])(inputs));
}
function getPublicId(url) {
    return url.split('/').slice(-2).join('/').split('.')[0];
}
function checkPinDetailsPage(pathname) {
    return /^\/pin\/[^\/]+\/?$/.test(pathname);
}
function checkUserPage(pathname) {
    return /^\/user\/[^\/]+\/?$/.test(pathname);
}
function checkBoardDetailsPage(pathname) {
    return /^\/user\/[^\/]+\/[^\/]+\/?$/.test(pathname);
}
}}),
"[project]/components/ui/card.tsx [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "Card": (()=>Card),
    "CardContent": (()=>CardContent),
    "CardDescription": (()=>CardDescription),
    "CardFooter": (()=>CardFooter),
    "CardHeader": (()=>CardHeader),
    "CardTitle": (()=>CardTitle)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/lib/utils.ts [app-rsc] (ecmascript)");
;
;
;
const Card = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["cn"])("rounded-xl border bg-card text-card-foreground shadow", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/card.tsx",
        lineNumber: 9,
        columnNumber: 3
    }, this));
Card.displayName = "Card";
const CardHeader = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["cn"])("flex flex-col space-y-1.5 p-6", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/card.tsx",
        lineNumber: 24,
        columnNumber: 3
    }, this));
CardHeader.displayName = "CardHeader";
const CardTitle = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["cn"])("font-semibold leading-none tracking-tight", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/card.tsx",
        lineNumber: 36,
        columnNumber: 3
    }, this));
CardTitle.displayName = "CardTitle";
const CardDescription = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["cn"])("text-sm text-muted-foreground", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/card.tsx",
        lineNumber: 48,
        columnNumber: 3
    }, this));
CardDescription.displayName = "CardDescription";
const CardContent = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["cn"])("p-6 pt-0", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/card.tsx",
        lineNumber: 60,
        columnNumber: 3
    }, this));
CardContent.displayName = "CardContent";
const CardFooter = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["cn"])("flex items-center p-6 pt-0", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/card.tsx",
        lineNumber: 68,
        columnNumber: 3
    }, this));
CardFooter.displayName = "CardFooter";
;
}}),
"[project]/app/(admin)/admin/pins/page.tsx [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>AdminPinsPage)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$actions$2f$pin$2d$actions$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/actions/pin-actions.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$pages$2f$admin$2f$pin$2d$table$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/components/pages/admin/pin-table.tsx [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/components/ui/card.tsx [app-rsc] (ecmascript)");
;
;
;
;
async function AdminPinsPage() {
    const pins = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$actions$2f$pin$2d$actions$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getAllPinsUserAction"])({});
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "space-y-4",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                className: "text-3xl font-bold tracking-tight",
                children: "Pins Management"
            }, void 0, false, {
                fileName: "[project]/app/(admin)/admin/pins/page.tsx",
                lineNumber: 9,
                columnNumber: 4
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Card"], {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["CardHeader"], {
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["CardTitle"], {
                            children: "Pins"
                        }, void 0, false, {
                            fileName: "[project]/app/(admin)/admin/pins/page.tsx",
                            lineNumber: 12,
                            columnNumber: 6
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/(admin)/admin/pins/page.tsx",
                        lineNumber: 11,
                        columnNumber: 5
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["CardContent"], {
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$pages$2f$admin$2f$pin$2d$table$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["PinsTable"], {
                            initialPins: pins
                        }, void 0, false, {
                            fileName: "[project]/app/(admin)/admin/pins/page.tsx",
                            lineNumber: 15,
                            columnNumber: 6
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/(admin)/admin/pins/page.tsx",
                        lineNumber: 14,
                        columnNumber: 5
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/(admin)/admin/pins/page.tsx",
                lineNumber: 10,
                columnNumber: 4
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/(admin)/admin/pins/page.tsx",
        lineNumber: 8,
        columnNumber: 3
    }, this);
}
}}),
"[project]/app/(admin)/admin/pins/page.tsx [app-rsc] (ecmascript, Next.js server component)": ((__turbopack_context__) => {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, t: __turbopack_require_real__ } = __turbopack_context__;
{
__turbopack_export_namespace__(__turbopack_import__("[project]/app/(admin)/admin/pins/page.tsx [app-rsc] (ecmascript)"));
}}),

};

//# sourceMappingURL=_24416e._.js.map