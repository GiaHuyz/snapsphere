# Backend for snapsphere

**Clerk JWT with Nestjs**

https://dev.to/robertoyamanaka/clerk-jwt-authentication-with-nestjs-passport-for-rest-graphql-23jf

- Have not done yet.

## how to run backend

```sh
cd backend
```

```sh
npm i
```

```sh
npm run dev
```

open http://localhost:8000/api to view api document