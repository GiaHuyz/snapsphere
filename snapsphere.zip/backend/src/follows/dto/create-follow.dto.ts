export class CreateFollowDto {}
